</section>
<footer>
    <div class="container">
        <div class="mandatory">
            Featherstone Partners &copy; <?php echo date('Y');?> All Rights Reserved <a href="">Disclaimer</a><a href="">Privacy Policy</a><a href="">Terms & Conditions</a>
        </div>
        <div class="help">
            <a href="" class="button button__raised button__inline">Help & Support</a>
        </div>

    </div>
</footer>
